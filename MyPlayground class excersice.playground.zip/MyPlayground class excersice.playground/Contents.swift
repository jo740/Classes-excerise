import UIKit

var str = "types of car colors"

class carcolors {
    
    var optionA = "red"
    var optionB = "black"
    var otpionC = "white"
    func chooseoption(a: String){
        
    }
}
var mycarcolor = carcolors()
mycarcolor.chooseoption(a: "optionA")

